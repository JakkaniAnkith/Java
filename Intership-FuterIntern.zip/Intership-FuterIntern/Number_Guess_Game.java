import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Number_Guess_Game extends JFrame {
    private JTextField guessField;
    private JButton guessButton;
    private JLabel resultLabel;
    private JLabel attemptsLabel;
    private int numberToGuess;
    private int numberOfTries;

    public Number_Guess_Game() {
        // Set up the frame
        setTitle("Number Guessing Game");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Set GridBagLayout for center alignment
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Add spacing between components

        // Generate a random number between 1 and 100
        Random random = new Random();
        numberToGuess = random.nextInt(100) + 1;
        numberOfTries = 0;

        // Create components
        JLabel instructionLabel = new JLabel("Guess the number between 1 and 100:");
        guessField = new JTextField(10);
        guessButton = new JButton("Guess");
        resultLabel = new JLabel("");
        attemptsLabel = new JLabel("Attempts: 0");

        // Set a bold font with a larger size (e.g., 18px, bold)
        Font font = new Font("Arial", Font.BOLD, 18);
        instructionLabel.setFont(font);
        guessField.setFont(font);
        guessButton.setFont(font);
        resultLabel.setFont(font);
        attemptsLabel.setFont(font);

        // Center alignment for the labels and other components
        instructionLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        attemptsLabel.setHorizontalAlignment(JLabel.CENTER);

        // Add components to the frame
        gbc.gridwidth = 1; // Set the component to take one column width
        add(instructionLabel, gbc);

        gbc.gridy++;
        add(guessField, gbc);

        gbc.gridy++;
        add(guessButton, gbc);

        gbc.gridy++;
        add(resultLabel, gbc);

        gbc.gridy++;
        add(attemptsLabel, gbc);

        // Set up the button action listener
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the user's guess
                    int userGuess = Integer.parseInt(guessField.getText());
                    numberOfTries++;

                    // Check if the guess is correct, too high, or too low
                    if (userGuess < numberToGuess) {
                        resultLabel.setText("Too low! Try again.");
                    } else if (userGuess > numberToGuess) {
                        resultLabel.setText("Too high! Try again.");
                    } else {
                        resultLabel.setText("Congratulations! You guessed it right.");
                    }

                    // Update attempts label
                    attemptsLabel.setText("Attempts: " + numberOfTries);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Please enter a valid number.");
                }

                // Clear the text field for the next guess
                guessField.setText("");
            }
        });

        // Make the frame visible
        setVisible(true);
    }

    public static void main(String[] args) {
        // Create the game window
        new Number_Guess_Game();
    }
}
