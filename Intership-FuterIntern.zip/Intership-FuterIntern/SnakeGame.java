import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class SnakeGame extends JPanel implements ActionListener, KeyListener {
    private final int WIDTH = 600;
    private final int HEIGHT = 400;
    private final int CELL_SIZE = 20;
    private final int DELAY = 150;

    private final ArrayList<Point> snake = new ArrayList<>();
    private Point food;

    private String direction = "RIGHT";
    private boolean running = false;
    private boolean paused = false;
    private int score = 0;
    private int bestScore = 0;

    private Timer timer;
    private JLabel scoreLabel;
    private JLabel bestScoreLabel;

    public SnakeGame(JLabel scoreLabel, JLabel bestScoreLabel) {
        this.scoreLabel = scoreLabel;
        this.bestScoreLabel = bestScoreLabel;

        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setBorder(new LineBorder(Color.YELLOW, 5)); // Yellow border for the game area
        setFocusable(true);
        addKeyListener(this);

        initGame();
    }

    private void initGame() {
        snake.clear();
        snake.add(new Point(100, 100)); // Initial snake position
        score = 0;
        direction = "RIGHT";
        createFood();
        running = false;
        paused = false;

        if (timer != null) {
            timer.stop();
        }
        timer = new Timer(DELAY, this);
        updateScoreLabels();
        repaint();
    }

    private void createFood() {
        Random random = new Random();
        int x, y;

        do {
            x = random.nextInt(WIDTH / CELL_SIZE) * CELL_SIZE;
            y = random.nextInt(HEIGHT / CELL_SIZE) * CELL_SIZE;
        } while (snake.contains(new Point(x, y)));

        food = new Point(x, y);
    }

    private void moveSnake() {
        Point head = snake.get(snake.size() - 1);
        Point newHead = new Point(head);

        switch (direction) {
            case "UP" -> newHead.y -= CELL_SIZE;
            case "DOWN" -> newHead.y += CELL_SIZE;
            case "LEFT" -> newHead.x -= CELL_SIZE;
            case "RIGHT" -> newHead.x += CELL_SIZE;
        }

        // Check collisions
        if (newHead.x < 0 || newHead.x >= WIDTH || newHead.y < 0 || newHead.y >= HEIGHT || snake.contains(newHead)) {
            gameOver();
            return;
        }

        // Add new head
        snake.add(newHead);

        // Check if food is eaten
        if (newHead.equals(food)) {
            score += 10;
            bestScore = Math.max(bestScore, score);
            createFood();
        } else {
            snake.remove(0); // Remove tail
        }

        updateScoreLabels();
    }

    private void startGame() {
        if (!running && !paused) {
            running = true;
            requestFocusInWindow(); // Ensure key events are captured
            timer.start();
        }
    }

    private void stopGame() {
        if (running) {
            running = false;
            timer.stop();
            paused = true;
        }
    }

    private void resumeGame() {
        if (!running && paused) {
            running = true;
            paused = false;
            timer.start();
        }
    }

    private void restartGame() {
        initGame();
        startGame();
    }

    private void gameOver() {
        running = false;
        timer.stop();
        JOptionPane.showMessageDialog(this, "Game Over! Your score: " + score, "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateScoreLabels() {
        scoreLabel.setText("Score: " + score);
        bestScoreLabel.setText("Best Score: " + bestScore);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (running) {
            drawGame(g);
        } else if (!running && paused) {
            drawPaused(g);
        } else {
            drawGameOver(g);
        }
    }

    private void drawGame(Graphics g) {
        // Draw food
        g.setColor(Color.RED);
        g.fillOval(food.x, food.y, CELL_SIZE, CELL_SIZE);

        // Draw snake
        g.setColor(Color.GREEN);
        for (Point p : snake) {
            g.fillRect(p.x, p.y, CELL_SIZE, CELL_SIZE);
        }
    }

    private void drawPaused(Graphics g) {
        g.setColor(Color.YELLOW);
        g.drawString("Game Paused", WIDTH / 2 - 40, HEIGHT / 2);
    }

    private void drawGameOver(Graphics g) {
        g.setColor(Color.WHITE);
        g.drawString("GAME OVER!", WIDTH / 2 - 50, HEIGHT / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            moveSnake();
            repaint();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if ((key == KeyEvent.VK_UP) && !direction.equals("DOWN")) {
            direction = "UP";
        } else if ((key == KeyEvent.VK_DOWN) && !direction.equals("UP")) {
            direction = "DOWN";
        } else if ((key == KeyEvent.VK_LEFT) && !direction.equals("RIGHT")) {
            direction = "LEFT";
        } else if ((key == KeyEvent.VK_RIGHT) && !direction.equals("LEFT")) {
            direction = "RIGHT";
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { }

    @Override
    public void keyTyped(KeyEvent e) { }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");

        // Create score and best score labels
        JLabel scoreLabel = new JLabel("Score: 0");
        JLabel bestScoreLabel = new JLabel("Best Score: 0");

        scoreLabel.setForeground(Color.WHITE);
        bestScoreLabel.setForeground(Color.WHITE);

        // Score panel for displaying the scores
        JPanel scorePanel = new JPanel();
        scorePanel.setBackground(Color.DARK_GRAY);
        scorePanel.add(scoreLabel);
        scorePanel.add(bestScoreLabel);

        // SnakeGame panel
        SnakeGame game = new SnakeGame(scoreLabel, bestScoreLabel);

        // Button panel with action listeners
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.DARK_GRAY);

        JButton startButton = new JButton("Start");
        startButton.addActionListener(e -> game.startGame());
        buttonPanel.add(startButton);

        JButton stopButton = new JButton("Stop");
        stopButton.addActionListener(e -> game.stopGame());
        buttonPanel.add(stopButton);

        JButton resumeButton = new JButton("Resume");
        resumeButton.addActionListener(e -> game.resumeGame());
        buttonPanel.add(resumeButton);

        JButton restartButton = new JButton("Restart");
        restartButton.addActionListener(e -> game.restartGame());
        buttonPanel.add(restartButton);

        // Create a JPanel as the root content pane with a white border
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(new LineBorder(Color.WHITE, 5)); // White border for the entire window
        contentPanel.add(buttonPanel, BorderLayout.NORTH);
        contentPanel.add(game, BorderLayout.CENTER);
        contentPanel.add(scorePanel, BorderLayout.SOUTH);

        frame.setContentPane(contentPanel);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}