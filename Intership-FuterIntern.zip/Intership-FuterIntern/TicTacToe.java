import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class TicTacToe extends JFrame {
    private String currentPlayer;  // Tracks the current player ('X' or 'O')
    private String[][] board;      // Represents the Tic-Tac-Toe board
    private JButton[][] buttons;   // Buttons representing the grid

    public TicTacToe() {
        // Initialize the window
        setTitle("Tic Tac Toe");
        setSize(400, 450);  // Set the window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
        getContentPane().setBackground(new Color(0xFFEBCD)); // Background color

        currentPlayer = "X";
        board = new String[3][3];
        buttons = new JButton[3][3];

        // Set up the layout manager and frame
        setLayout(new BorderLayout());

        // Create the game board
        JPanel gamePanel = new JPanel();
        gamePanel.setLayout(new GridLayout(3, 3));  // 3x3 grid layout
        gamePanel.setBackground(new Color(0xFFEBCD));  // Set panel background

        // Create the buttons for the grid
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new JButton("");
                buttons[i][j].setFont(new Font("Arial", Font.BOLD, 24));  // Set font size and style
                buttons[i][j].setBackground(new Color(0xF0F8FF));  // Light blue background
                buttons[i][j].setForeground(new Color(0x333333));  // Text color
                buttons[i][j].setFocusPainted(false);
                buttons[i][j].addActionListener(new ButtonClickListener(i, j));
                gamePanel.add(buttons[i][j]);
            }
        }

        // Add the game panel to the frame
        add(gamePanel, BorderLayout.CENTER);

        // Restart game button
        JButton restartButton = new JButton("Restart Game");
        restartButton.setFont(new Font("Arial", Font.BOLD, 16));
        restartButton.setBackground(new Color(0x90EE90));  // Light green
        restartButton.setForeground(new Color(0x333333));  // Dark text
        restartButton.addActionListener(e -> resetGame());
        add(restartButton, BorderLayout.SOUTH);  // Add button to the bottom

        // Make the frame visible
        setVisible(true);
    }

    // Button click handler
    private class ButtonClickListener implements ActionListener {
        private int row;
        private int col;

        public ButtonClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (board[row][col] == null) {
                board[row][col] = currentPlayer;
                buttons[row][col].setText(currentPlayer);
                buttons[row][col].setForeground(currentPlayer.equals("X") ? Color.ORANGE : Color.BLUE);
                if (checkWin(currentPlayer)) {
                    JOptionPane.showMessageDialog(null, "Player " + currentPlayer + " wins!");
                    resetGame();
                } else if (checkDraw()) {
                    JOptionPane.showMessageDialog(null, "It's a draw!");
                    resetGame();
                } else {
                    currentPlayer = currentPlayer.equals("X") ? "O" : "X";  // Switch player
                }
            } else {
                JOptionPane.showMessageDialog(null, "Cell already taken! Choose another.");
            }
        }
    }

    // Method to check if the current player has won
    private boolean checkWin(String player) {
        // Check rows, columns, and diagonals
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] != null && board[i][0].equals(player) && 
                 board[i][1] != null && board[i][1].equals(player) && 
                 board[i][2] != null && board[i][2].equals(player)) || 
                (board[0][i] != null && board[0][i].equals(player) && 
                 board[1][i] != null && board[1][i].equals(player) && 
                 board[2][i] != null && board[2][i].equals(player))) {
                return true;
            }
        }
        if ((board[0][0] != null && board[0][0].equals(player) && 
             board[1][1] != null && board[1][1].equals(player) && 
             board[2][2] != null && board[2][2].equals(player)) || 
            (board[0][2] != null && board[0][2].equals(player) && 
             board[1][1] != null && board[1][1].equals(player) && 
             board[2][0] != null && board[2][0].equals(player))) {
            return true;
        }
        return false;
    }

    // Method to check if it's a draw
    private boolean checkDraw() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == null) {
                    return false;
                }
            }
        }
        return true;
    }

    // Method to reset the game
    private void resetGame() {
        currentPlayer = "X";
        board = new String[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
                buttons[i][j].setForeground(new Color(0x333333));
            }
        }
    }

    public static void main(String[] args) {
        // Create and run the game
        SwingUtilities.invokeLater(() -> new TicTacToe());
    }
}
