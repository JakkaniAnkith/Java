import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.SecureRandom;

public class RandomPasswordGenerator {
    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("Random Password Generator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600);
        frame.setLayout(new GridBagLayout()); // Use GridBagLayout for centering
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15); // Padding between components

        // Title label
        JLabel titleLabel = new JLabel("Random Password Generator", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20)); // Increased font size and thickness
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Span across two columns
        frame.add(titleLabel, gbc);

        // Password length label and text field
        JLabel lengthLabel = new JLabel("Password Length:");
        lengthLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size and thickness
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // Reset to single column
        gbc.anchor = GridBagConstraints.EAST; // Align right
        frame.add(lengthLabel, gbc);

        JTextField lengthField = new JTextField(10);
        lengthField.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST; // Align left
        frame.add(lengthField, gbc);

        // Checkbox for character options
        JCheckBox uppercaseCheck = new JCheckBox("Uppercase Letters");
        uppercaseCheck.setFont(new Font("Arial", Font.BOLD, 14)); // Increased font size
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER; // Center-align
        frame.add(uppercaseCheck, gbc);

        JCheckBox lowercaseCheck = new JCheckBox("Lowercase Letters");
        lowercaseCheck.setFont(new Font("Arial", Font.BOLD, 14)); // Increased font size
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        frame.add(lowercaseCheck, gbc);

        JCheckBox numbersCheck = new JCheckBox("Numbers or Digits");
        numbersCheck.setFont(new Font("Arial", Font.BOLD, 14)); // Increased font size
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        frame.add(numbersCheck, gbc);

        JCheckBox specialCharCheck = new JCheckBox("Special Characters");
        specialCharCheck.setFont(new Font("Arial", Font.BOLD, 14)); // Increased font size
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        frame.add(specialCharCheck, gbc);

        // Generate password button
        JButton generateButton = new JButton("Generate Password");
        generateButton.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size and thickness
        generateButton.setBackground(new Color(72, 201, 176)); // Custom button color (light green)
        generateButton.setForeground(Color.WHITE); // White text color
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        frame.add(generateButton, gbc);

        // Display generated password
        JLabel resultLabel = new JLabel("Generated Password:");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Increased font size and thickness
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        frame.add(resultLabel, gbc);

        JLabel passwordLabel = new JLabel("", SwingConstants.CENTER);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Increased font size
        passwordLabel.setForeground(new Color(41, 128, 185)); // Custom color for password display (blue)
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        frame.add(passwordLabel, gbc);

        // Add action listener to the generate button
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String lengthText = lengthField.getText();
                int length;

                // Validate length input
                try {
                    length = Integer.parseInt(lengthText);
                    if (length < 8) {
                        JOptionPane.showMessageDialog(frame, 
                            "Password length should be at least 8 characters.", 
                            "Invalid Length", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter a valid number for password length.", 
                        "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Build character set based on checkboxes
                StringBuilder characters = new StringBuilder();
                if (uppercaseCheck.isSelected()) {
                    characters.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                }
                if (lowercaseCheck.isSelected()) {
                    characters.append("abcdefghijklmnopqrstuvwxyz");
                }
                if (numbersCheck.isSelected()) {
                    characters.append("0123456789");
                }
                if (specialCharCheck.isSelected()) {
                    characters.append("!@#$%^&*()-_=+[]{}|;:,.<>?");
                }

                if (characters.length() == 0) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please select at least one character set.", 
                        "Invalid Selection", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Generate password
                String password = generateRandomPassword(characters.toString(), length);
                passwordLabel.setText(password);
            }
        });

        // Set frame visibility
        frame.setVisible(true);
    }

    // Method to generate a random password
    private static String generateRandomPassword(String characters, int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            password.append(characters.charAt(index));
        }

        return password.toString();
    }
}
