import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class cal extends JFrame implements ActionListener {
    // Components of the calculator
    private JTextField display;
    private JButton[] numberButtons = new JButton[10];
    private JButton addButton, subButton, mulButton, divButton, equalsButton, clearButton;
    private JPanel buttonPanel;

    // Variables for operations
    private double currentResult = 0;
    private String operator = "";
    private boolean isNewOperation = true;

    // Constructor
    public cal() {
        setTitle("Advanced Calculator");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Display field
        display = new JTextField("0");
        display.setFont(new Font("Arial", Font.BOLD, 24));
        display.setEditable(false);
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        add(display, BorderLayout.NORTH);

        // Buttons
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 4, 10, 10));

        // Number buttons
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFont(new Font("Arial", Font.BOLD, 18));
            numberButtons[i].addActionListener(this);
            buttonPanel.add(numberButtons[i]);
        }

        // Operation buttons
        addButton = createButton("+");
        subButton = createButton("-");
        mulButton = createButton("*");
        divButton = createButton("/");
        equalsButton = createButton("=");
        clearButton = createButton("C");

        // Add buttons to panel
        buttonPanel.add(addButton);
        buttonPanel.add(subButton);
        buttonPanel.add(mulButton);
        buttonPanel.add(divButton);
        buttonPanel.add(equalsButton);
        buttonPanel.add(clearButton);

        add(buttonPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    // Helper method to create buttons
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.addActionListener(this);
        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        // Number buttons
        for (int i = 0; i < 10; i++) {
            if (source == numberButtons[i]) {
                if (isNewOperation) {
                    display.setText(""); // Clear for new input
                    isNewOperation = false;
                }
                display.setText(display.getText() + i);
            }
        }

        // Operation buttons
        if (source == addButton) {
            performCalculation();
            operator = "+";
        } else if (source == subButton) {
            performCalculation();
            operator = "-";
        } else if (source == mulButton) {
            performCalculation();
            operator = "*";
        } else if (source == divButton) {
            performCalculation();
            operator = "/";
        } else if (source == equalsButton) {
            performCalculation();
            operator = "";
        } else if (source == clearButton) {
            display.setText("0");
            currentResult = 0;
            operator = "";
            isNewOperation = true;
        }
    }

    private void performCalculation() {
        double currentNumber = Double.parseDouble(display.getText());

        switch (operator) {
            case "+":
                currentResult += currentNumber;
                break;
            case "-":
                currentResult -= currentNumber;
                break;
            case "*":
                currentResult *= currentNumber;
                break;
            case "/":
                if (currentNumber != 0) {
                    currentResult /= currentNumber;
                } else {
                    display.setText("Error");
                    currentResult = 0;
                    operator = "";
                    return;
                }
                break;
            default:
                currentResult = currentNumber;
        }

        display.setText(String.valueOf(currentResult));
        isNewOperation = true;
    }

    public static void main(String[] args) {
        new cal();
    }
}