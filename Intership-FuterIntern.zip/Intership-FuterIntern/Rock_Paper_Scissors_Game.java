import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.*;

public class Rock_Paper_Scissors_Game extends JFrame {
    private JLabel userChoiceLabel, computerChoiceLabel, resultLabel;
    private Random random;

    public Rock_Paper_Scissors_Game() {
        // Set up the frame
        setTitle("Rock, Paper, Scissors Game");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create a Random object to simulate the computer's choice
        random = new Random();

        // Set up the layout and center components
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Create labels for displaying choices and results
        userChoiceLabel = new JLabel("You chose:");
        userChoiceLabel.setFont(new Font("Arial", Font.BOLD, 18));
        userChoiceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        computerChoiceLabel = new JLabel("Computer chose:");
        computerChoiceLabel.setFont(new Font("Arial", Font.BOLD, 18));
        computerChoiceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        resultLabel = new JLabel("Let's play!");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 20));
        resultLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add labels to the frame with gaps
        add(userChoiceLabel);
        add(Box.createVerticalStrut(20)); // Adds gap between labels
        add(computerChoiceLabel);
        add(Box.createVerticalStrut(20)); // Adds gap between labels
        add(resultLabel);
        add(Box.createVerticalStrut(20)); // Adds gap after result label

        // Create buttons for the user to select rock, paper, or scissors
        JButton rockButton = new JButton("Rock");
        rockButton.setFont(new Font("Arial", Font.BOLD, 18));
        rockButton.setBackground(Color.CYAN);
        rockButton.setPreferredSize(new Dimension(150, 50));
        rockButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton paperButton = new JButton("Paper");
        paperButton.setFont(new Font("Arial", Font.BOLD, 18));
        paperButton.setBackground(new Color(144, 238, 144));  // Light green color
        paperButton.setPreferredSize(new Dimension(150, 50));
        paperButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton scissorsButton = new JButton("Scissors");
        scissorsButton.setFont(new Font("Arial", Font.BOLD, 18));
        scissorsButton.setBackground(Color.PINK);
        scissorsButton.setPreferredSize(new Dimension(150, 50));
        scissorsButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Add buttons to the frame
        add(rockButton);
        add(Box.createVerticalStrut(10)); // Adds small gap between buttons
        add(paperButton);
        add(Box.createVerticalStrut(10)); // Adds small gap between buttons
        add(scissorsButton);

        // Action listeners for the buttons
        rockButton.addActionListener(new ChoiceButtonListener("rock"));
        paperButton.addActionListener(new ChoiceButtonListener("paper"));
        scissorsButton.addActionListener(new ChoiceButtonListener("scissors"));

        // Set the frame to be visible
        setVisible(true);
    }

    // Method to determine the winner
    private String determineWinner(String userChoice, String computerChoice) {
        if (userChoice.equals(computerChoice)) {
            return "It's a tie!";
        }
        switch (userChoice) {
            case "rock":
                return computerChoice.equals("scissors") ? "You win!" : "Computer wins!";
            case "paper":
                return computerChoice.equals("rock") ? "You win!" : "Computer wins!";
            case "scissors":
                return computerChoice.equals("paper") ? "You win!" : "Computer wins!";
            default:
                return "Invalid choice!";
        }
    }

    // Method to handle the user's choice and compute the result
    private void userChoice(String choice) {
        // List of choices
        String[] choices = {"rock", "paper", "scissors"};

        // Randomly pick computer's choice
        String computerChoice = choices[random.nextInt(3)];

        // Determine the winner
        String result = determineWinner(choice, computerChoice);

        // Update the labels with choices and result
        userChoiceLabel.setText("You chose: " + choice.substring(0, 1).toUpperCase() + choice.substring(1));
        computerChoiceLabel.setText("Computer chose: " + computerChoice.substring(0, 1).toUpperCase() + computerChoice.substring(1));
        resultLabel.setText(result);
    }

    // Action listener for the buttons
    private class ChoiceButtonListener implements ActionListener {
        private String choice;

        public ChoiceButtonListener(String choice) {
            this.choice = choice;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            userChoice(choice);
        }
    }

    public static void main(String[] args) {
        // Create the game window
        new Rock_Paper_Scissors_Game();
    }
}
